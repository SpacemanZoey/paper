
import tensorflow as tf
import tensorflow.keras.layers as kl
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import preprocessing
tf.compat.v1.disable_v2_behavior()
#读入训练数据样本
train_size_df = pd.read_csv('./服务器发送训练数据大小读取.txt', sep=" ", header=None)
train_size_df.columns = ['server1', 'server2', 'server3', 'server4', 'server5', 'server6', 'server7', 'server8',
                     'server9', 'server10', 'server11', 'server12', 'server13', 'server14', 'server15', 'server16', 'server17', 'server18', 'server19',
                     'server20', 'server21', 'server22', 'server23', 'server24', 'server25', 'server26','server27', 'server28', 'server29', 'server30', 'server31', 'server32', 'server33', 'server34',
                     'server35', 'server36', 'server37', 'server38', 'server39', 'server40', 'server41', 'server42', 'server43', 'server44', 'server45',
                     'server46', 'server47', 'server48', 'server49', 'server50', 'server51', 'server52','server53', 'server54']
train_time_df = pd.read_csv('./服务器发送训练数据时间限制.txt', sep=" ", header=None)
train_time_df.columns = ['timelimit1', 'timelimit2', 'timelimit3', 'timelimit4', 'timelimit5', 'timelimit6', 'timelimit7', 'timelimit8',
                     'timelimit9', 'timelimit10', 'timelimit11', 'timelimit12', 'timelimit13', 'timelimit14', 'timelimit15', 'timelimit16', 'timelimit17', 'timelimit18', 'timelimit19',
                     'timelimit20', 'timelimit21', 'timelimit22', 'timelimit23', 'timelimit24', 'timelimit25', 'timelimit26','timelimit27', 'timelimit28', 'timelimit29', 'timelimit30', 'timelimit31', 'timelimit32', 'timelimit33', 'timelimit34',
                     'timelimit35', 'timelimit36', 'timelimit37', 'timelimit38', 'timelimit39', 'timelimit40', 'timelimit41', 'timelimit42', 'timelimit43', 'timelimit44', 'timelimit45',
                     'timelimit46', 'timelimit47', 'timelimit48', 'timelimit49', 'timelimit50', 'timelimit51', 'timelimit52','timelimit53', 'timelimit54']

#读入测试数据样本
test_size_df = pd.read_csv('./服务器发送预测数据大小读取.txt', sep=" ", header=None)
test_size_df.columns = ['server1', 'server2', 'server3', 'server4', 'server5', 'server6', 'server7', 'server8',
                     'server9', 'server10', 'server11', 'server12', 'server13', 'server14', 'server15', 'server16', 'server17', 'server18', 'server19',
                     'server20', 'server21', 'server22', 'server23', 'server24', 'server25', 'server26','server27', 'server28', 'server29', 'server30', 'server31', 'server32', 'server33', 'server34',
                     'server35', 'server36', 'server37', 'server38', 'server39', 'server40', 'server41', 'server42', 'server43', 'server44', 'server45',
                     'server46', 'server47', 'server48', 'server49', 'server50', 'server51', 'server52','server53', 'server54']
test_time_df = pd.read_csv('./服务器发送预测数据时间限制.txt', sep=" ", header=None)
test_time_df.columns = ['timelimit1', 'timelimit2', 'timelimit3', 'timelimit4', 'timelimit5', 'timelimit6', 'timelimit7', 'timelimit8',
                     'timelimit9', 'timelimit10', 'timelimit11', 'timelimit12', 'timelimit13', 'timelimit14', 'timelimit15', 'timelimit16', 'timelimit17', 'timelimit18', 'timelimit19',
                     'timelimit20', 'timelimit21', 'timelimit22', 'timelimit23', 'timelimit24', 'timelimit25', 'timelimit26','timelimit27', 'timelimit28', 'timelimit29', 'timelimit30', 'timelimit31', 'timelimit32', 'timelimit33', 'timelimit34',
                     'timelimit35', 'timelimit36', 'timelimit37', 'timelimit38', 'timelimit39', 'timelimit40', 'timelimit41', 'timelimit42', 'timelimit43', 'timelimit44', 'timelimit45',
                     'timelimit46', 'timelimit47', 'timelimit48', 'timelimit49', 'timelimit50', 'timelimit51', 'timelimit52','timelimit53', 'timelimit54']

w0 = 20#定义20个周期时间单位

#训练数据处理
for i in range(1,57):  #56个服务器
       train=[]
       train=train.append(train_size_df['server'+repr(i)])
       trian=train.append(train_time_df['timelimit'+repr(i)])

#测试数据处理
for i in range(1,57):  #56个服务器
       test=[]
       test=test.append(test_size_df['server'+repr(i)])
       test=test.append(test_time_df['timelimit'+repr(i)])
min_max_scaler = preprocessing.MinMaxScaler()
norm_train_df = pd.DataFrame(min_max_scaler.fit_transform(train_df[cols_normalize]),
                             columns=cols_normalize,
                             index=train_df.index)
BATCH_SIZE = 80#指定批次
#定义训练数据集
dataset = tf.data.Dataset.from_tensor_slices((seq_array, (label_array,labelreg_array))).shuffle(1000)
dataset = dataset.repeat().batch(BATCH_SIZE)
import JANetLSTMCell
tf.compat.v1.reset_default_graph()
learning_rate = 0.001
units = 128#GRU单元个数
#构建网络节点
nb_features = seq_array.shape[2]
nb_out = label_array.shape[1]
reg_out= labelreg_array.shape[1]
x = tf.compat.v1.placeholder("float", [None, sequence_length, nb_features])
y = tf.compat.v1.placeholder(tf.int32, [None, nb_out])
yreg = tf.compat.v1.placeholder("float", [None, reg_out])
#
hidden = [100,50,36,24]         #配置每层的JANET单元个数
#运用JANETLSTMCell.PY进行配置
lstm1=JANetLSTMCell.JANetLSTMCell(hidden[0], t_max=sequence_length,recurrent_dropout=0.8)
rnn=kl.RNN(cell=lstm1,return_sequences=True)(x)
lstm2=JANetLSTMCell.JANetLSTMCell(hidden[1], recurrent_dropout=0.8)
rnn=kl.RNN(cell=lstm2,return_sequences=True)(rnn)
lstm3=JANetLSTMCell.JANetLSTMCell(hidden[2], recurrent_dropout=0.8)
rnn=kl.RNN(cell=lstm3,return_sequences=True)(rnn)
lstm4=JANetLSTMCell.JANetLSTMCell(hidden[3], recurrent_dropout=0.8)
rnn=kl.RNN(cell=lstm4,return_sequences=True)(rnn)
outputs = rnn
outputs = tf.transpose(a=outputs, perm=[1, 0, 2])
print(outputs.get_shape())

prediction_regression =kl.Conv2D(1,1,activation = 'sigmoid')(tf.reshape(outputs[-1],[-1,1,1,36]))
prediction_regression =tf.reshape(prediction_regression, (-1, 1))

cost = tf.reduce_mean(input_tensor=abs(prediction_regression - yreg))

optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)#Adma优化器进行优化

iterator = tf.compat.v1.data.make_one_shot_iterator(dataset)			#生成一个训练集的迭代器
one_element = iterator.get_next()

iterator_test = tf.compat.v1.data.make_one_shot_iterator(testdataset)			#生成一个测试集的迭代器
one_element_test = iterator_test.get_next()

EPOCHS = 10000   #指定迭代次数
with tf.compat.v1.Session() as sess:
    sess.run(tf.compat.v1.global_variables_initializer())  #任意初始化所有数据开始训练
    for epoch in range(EPOCHS):#训练模型
        alloss = []
        inp, (target,targetregression) = sess.run(one_element)
        if len(inp)!= BATCH_SIZE:
            continue
        predregv,_,loss =sess.run([predregression,optimizer,cost], feed_dict={x: inp, y: target,yreg:targetregression})
        alloss.append(loss)
        if epoch%100==0: #每个100次打印一次结果
            print(np.mean(alloss))


#测试模型
    alloss = []	#收集loss值
    while True:
        try:
            inp, (target, targetregression) = sess.run(one_element_test)
            predv,predregv,loss =sess.run([pred, prediction_regression, cost],
                                          feed_dict={x: inp, y: target, yreg:targetregression})
            alloss.append(loss)
            print("预测结果：",np.asarray(targetregression[:20]*train_df['loss'].max()
                                     +train_df['pred'].min(),np.int32)[:,0],
                  np.asarray(predregressionv[:20]*train_df['pred'].max()
                             +train_df['pred'].min(),np.int32)[:,0])
            print(loss)

        except tf.errors.OutOfRangeError:
            print("测试结束")
            #可视化显示
            y_true_test = np.asarray(targetregression * train_df['pred'].max()
                                     + train_df['pred'].min(), np.int32)[:, 0]
            y_pred_test = np.asarray(predregv*train_df['pred'].max()+train_df['pred'].min(),np.int32)[:,0]
            fig_verify = plt.figure(figsize=(12, 8))
            plt.plot(y_pred_test, color="blue")
            plt.plot(y_true_test, color="green")
            plt.title('动态网络流预测器预测结果')
            plt.ylabel('网络流（1000 Byte）')
            plt.xlabel('时间单位')
            plt.legend(['预测流', '真实流'], loc='upper left')
            plt.show()
            fig_verify.savefig("./dynamic_network_traffic_prediction.png")
            print(np.mean(alloss))
            break
