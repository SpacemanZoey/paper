from abc import ABC, abstractmethod


class Algorithm(ABC):
    @abstractmethod
    def __call__(self, *args, **kwargs):
        pass
