from playground.auxiliary.episode import Episode
from .broker import Broker

Episode.broker_cls = Broker
