from core.broker import Broker
from .job import Job

Broker.job_cls = Job
