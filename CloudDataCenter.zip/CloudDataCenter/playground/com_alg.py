import os
import time
import numpy as np
import tensorflow as tf
from multiprocessing import Process, Manager,  freeze_support
import sys
import warnings

warnings.filterwarnings('ignore')

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
sys.path.append('/Users/zzzzy/Documents/CloudDataCenter/')

from core.machine import MachineConfig
from Algorithm.first_fit import FirstFitAlgorithm
from Algorithm.random_algorithm import RandomAlgorithm
from utils.csv_reader import CSVReader
from utils.episode import Episode
from utils.tools import multiprocessing_run, average_completion, average_slowdown


os.environ['CUDA_VISIBLE_DEVICES'] = ''
machines_number = 5
jobs_len = 100
jobs_csv = '/Users/zzzzy/Documents/CloudDataCenter/data/jobs.csv'

machine_configs = [MachineConfig(64, 1, 1) for i in range(machines_number)]
csv_reader = CSVReader(jobs_csv)
jobs_configs = csv_reader.generate(0, jobs_len)


# tic = time.time()
# algorithm = FirstFitAlgorithm()
# episode = Episode(machine_configs, jobs_configs, algorithm, "ff.csv")
# episode.run()
# print(episode.env.now, time.time() - tic, average_completion(episode), average_slowdown(episode))
print("xxxxxxxxxxxxxxxxxxxxxxxxxxxx")
tic = time.time()
algorithm = RandomAlgorithm()
episode = Episode(machine_configs, jobs_configs, algorithm, "rd.csv")
episode.run()
#print(episode.env.now, time.time() - tic, average_completion(episode), average_slowdown(episode))

# tic = time.time()
# algorithm = FirstFitAlgorithm()
# episode = Episode(machine_configs, jobs_configs, algorithm, None)
# episode.run()
# print(episode.env.now, time.time() - tic, average_completion(episode), average_slowdown(episode))